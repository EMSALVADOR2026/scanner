@echo off
title Instalador del Agente Escaner
echo ================================================
echo   Instalando agente del escaner...
echo ================================================
echo.
set SCRIPT_DIR=%~dp0
set STARTUP_DIR=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup

set INSTALL_DIR=%USERPROFILE%\ScannerAgente
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"
copy "%SCRIPT_DIR%scan.ps1" "%INSTALL_DIR%\scan.ps1" /Y

(
echo Dim Shell
echo Set Shell = CreateObject^("WScript.Shell"^)
echo Shell.Run "powershell -WindowStyle Hidden -ExecutionPolicy Bypass -File ""%INSTALL_DIR%\scan.ps1"" -ServerUrl ""http://localhost:8000"" -Token ""P3uGVs0EIomc9Pn40yuGjMJL4KPUd9ZIaKolxak80OBJ24f30AgI4P5LBMCQxAjT""", 0, False
echo Set Shell = Nothing
) > "%STARTUP_DIR%\ScannerAgente.vbs"

start "" wscript.exe "%STARTUP_DIR%\ScannerAgente.vbs"

echo.
echo [OK] Agente instalado en: %INSTALL_DIR%
echo [OK] Se iniciara automaticamente al encender la PC
echo [OK] Corriendo en segundo plano ahora mismo
echo.
pause
