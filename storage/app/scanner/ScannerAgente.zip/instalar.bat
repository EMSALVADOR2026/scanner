@echo off
set INSTALL_DIR=%USERPROFILE%\ScannerAgente
set STARTUP_DIR=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"
if not exist "%INSTALL_DIR%\processed" mkdir "%INSTALL_DIR%\processed"
copy "%~dp0scan.ps1" "%INSTALL_DIR%\scan.ps1" /Y

:: Crea el .env con las credenciales
(
echo SCANNER_SERVER_URL=http://localhost:8000
echo SCANNER_TOKEN=P3uGVs0EIomc9Pn40yuGjMJL4KPUd9ZIaKolxak80OBJ24f30AgI4P5LBMCQxAjT
echo SCANNER_WATCH_FOLDER=%USERPROFILE%\Documents
echo SCANNER_ARCHIVE_FOLDER=%INSTALL_DIR%\processed
echo SCANNER_WAIT_SECONDS=60
) > "%INSTALL_DIR%\.env"

(
echo Dim Shell
echo Set Shell = CreateObject^("WScript.Shell"^)
echo Shell.Run "powershell -WindowStyle Hidden -ExecutionPolicy Bypass -File ""%INSTALL_DIR%\scan.ps1""", 0, False
echo Set Shell = Nothing
) > "%STARTUP_DIR%\ScannerAgente.vbs"

start "" wscript.exe "%STARTUP_DIR%\ScannerAgente.vbs"
echo [OK] Agente instalado
echo [OK] Servidor: http://localhost:8000
pause
