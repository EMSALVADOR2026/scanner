@echo off
title Instalador del Agente Escaner Epson
echo ================================================
echo   Instalando agente del escaner Epson...
echo ================================================
echo.
set SCRIPT_DIR=%~dp0
set STARTUP_DIR=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup
set INSTALL_DIR=%USERPROFILE%\ScannerAgente
set WATCH_FOLDER=%USERPROFILE%\Documents
set ARCHIVE_FOLDER=C:\ScannerAgente\processed
echo.
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"
if not exist "%WATCH_FOLDER%" mkdir "%WATCH_FOLDER%"
if not exist "%ARCHIVE_FOLDER%" mkdir "%ARCHIVE_FOLDER%"
copy "%SCRIPT_DIR%scan.ps1" "%INSTALL_DIR%\scan.ps1" /Y
echo Dim Shell > "%INSTALL_DIR%\ScannerAgente.vbs"
echo Set Shell = CreateObject("WScript.Shell") >> "%INSTALL_DIR%\ScannerAgente.vbs"
echo Shell.Run "powershell -WindowStyle Hidden -ExecutionPolicy Bypass -File ""%INSTALL_DIR%\scan.ps1"" -ServerUrl ""http://localhost:8000"" -Token ""P3uGVs0EIomc9Pn40yuGjMJL4KPUd9ZIaKolxak80OBJ24f30AgI4P5LBMCQxAjT"" -WatchFolder ""%WATCH_FOLDER%"" -ArchiveFolder ""%ARCHIVE_FOLDER%"" -WaitSeconds 60", 0, False >> "%INSTALL_DIR%\ScannerAgente.vbs"
echo Set Shell = Nothing >> "%INSTALL_DIR%\ScannerAgente.vbs"
copy "%INSTALL_DIR%\ScannerAgente.vbs" "%STARTUP_DIR%\ScannerAgente.vbs" /Y
start "" wscript.exe "%STARTUP_DIR%\ScannerAgente.vbs"
echo.
echo [OK] Agente instalado correctamente
echo [OK] Carpeta de entrada: %WATCH_FOLDER%
echo [OK] Carpeta procesados: %ARCHIVE_FOLDER%
echo [OK] Se iniciara automaticamente al encender la PC
echo [OK] El escaneo ahora lo controla Epson (Document Capture Pro)
echo.
pause
